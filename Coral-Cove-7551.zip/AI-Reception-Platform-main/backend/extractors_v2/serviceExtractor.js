'use strict';
const { extractJsonLd } = require('./utils');

const PRICE_REGEX = /(?:de la\s+)?(\d{1,5}(?:[.,]\d{2}?)?)\s*(?:lei|ron|€|eur|\$)/i;

function cleanName(name) {
  return name.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').replace(/^[\-–—•·\s]+/,'').trim();
}

function isValidName(name) {
  if (!name || name.length < 3 || name.length > 120) return false;
  // Reject lines that are pure parenthetical descriptions
  if (/^[\s(][\s(]*[\(]/.test(name) || /^\s*\(/.test(name)) return false;
  if (!/[a-zA-ZăâîșțĂÂÎȘȚ]{3,}/.test(name)) return false;
  if (/^[\\/\d\s\-\+\.]+$/.test(name)) return false;
  const junk = ["reducere","discount","oferta","promotie","click","vezi","afla","cumpara","adauga","selecteaza","detalii","contact","acasa","home","menu","despre","blog","stiri","cookies","newsletter","privacy"];
  const lower = name.toLowerCase().trim();
  if (junk.some(j => lower === j || lower.startsWith(j+" "))) return false;
  return true;
}

function extractServices(html, page='homepage') {
  const services = [];
  const seen = new Set();

  function add(name, price, source, method, confidence) {
    const n = cleanName(name);
    if (!isValidName(n)) return;
    if (seen.has(n.toLowerCase())) return;
    seen.add(n.toLowerCase());
    services.push({ name: n, price: price ? price.replace(/\s+/g,' ').trim().toUpperCase() : null, source, method, confidence, page });
  }

  // JSON-LD (95%)
  extractJsonLd(html).forEach(item => {
    [].concat(item.offers||[]).forEach(o => { if (o.name) add(o.name, o.price?o.price+' LEI':null,'json_ld','JSON-LD Offer',95); });
  });

  // Table rows (88%)
  [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)].forEach(m => {
    const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(c=>c[1].replace(/<[^>]+>/g,'').trim());
    if (cells.length >= 2) {
      const priceCell = cells.find(c=>PRICE_REGEX.test(c));
      const nameCell = cells.find(c=>!PRICE_REGEX.test(c)&&c.length>3&&/[a-zA-ZăâîșțĂÂÎȘȚ]{3,}/.test(c));
      if (priceCell && nameCell) add(nameCell, priceCell,'html_table','table row',88);
    }
  });

  // List items (85%)
  [...html.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)].forEach(m => {
    const text = m[1].replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
    const pm = text.match(PRICE_REGEX);
    if (pm) add(text.replace(pm[0],'').replace(/[-–:.\s]+$/,'').trim(), pm[0],'html_list','li with price',85);
  });

  // Dash/tilde pattern (82%)
  const lines = html.replace(/<[^>]+>/g,'\n').split('\n').map(l=>l.trim()).filter(l=>l.length>2);
  lines.forEach(line => {
    // Pattern: "Serviciu de la 150 RON" or "Serviciu — 150 RON"
    const delaMatch = line.match(/^([A-ZĂÂÎȘȚa-zăâîșț][^0-9]{5,80}?)\s+de la\s+(\d{1,5})\s*(?:RON|lei|ron|€)/i);
    if (delaMatch) add(delaMatch[1].replace(/[-–]+$/,'').trim(), delaMatch[2]+' RON', 'text_lines', 'de la price', 82);
    const m = line.match(/^([A-ZĂÂÎȘȚa-zăâîșț][^–~\-]{3,80}?)\s*[–~-]\s*(\d{1,5}(?:[.,]\d{2})?)\s*(?:lei|ron|RON|€)/i);
    if (m) add(m[1].replace(/[-–]+$/,'').trim(), m[2]+' LEI','text_lines','name – price',82);
    const m2 = line.match(/^([A-ZĂÂÎȘȚa-zăâîșț][^~]{3,80}?)\s*~\s*(\d{1,5})\s*lei/i);
    if (m2) add(m2[1].trim(), m2[2]+' LEI','text_lines','name ~ price',80);
  });

  // ── WOODMART THEME CARD DETECTOR ────────────────────────────
  // Pattern: WoodMart titles paired with bold span prices
  const woodmartTitles = [];
  const wmTitleRegex = /<h[2-6][^>]*woodmart-title[^>]*>([^<]{3,120})<\/h[2-6]>/gi;
  let wmm;
  while ((wmm = wmTitleRegex.exec(html)) !== null) {
    woodmartTitles.push({ name: wmm[1].trim(), pos: wmm.index });
  }

  if (woodmartTitles.length > 0) {
    // Find bold/colored span prices (WoodMart pattern)
    const boldSpanPrices = [];
    const bspRegex = /<span[^>]*(?:font-weight:\s*bold|font-weight:bold|color:#)[^>]*>(\d{1,5}(?:[.,]\d{0,2})?)\s*(?:Lei|RON|ron|lei|€)<\/span>/gi;
    let bsp;
    while ((bsp = bspRegex.exec(html)) !== null) {
      boldSpanPrices.push({ price: bsp[1], pos: bsp.index });
    }

    for (const card of woodmartTitles) {
      const nextPrice = boldSpanPrices.find(p => p.pos > card.pos && p.pos < card.pos + 20000);
      if (nextPrice) {
        const name = card.name.split('|')[0].trim();
        if (isValidName(name) && name.length > 3) {
          add(name, nextPrice.price + ' LEI', 'woodmart', 'woodmart card', 90);
        }
      }
    }
    if (woodmartTitles.length > 0) console.log('[EXTRACTOR] WoodMart:', woodmartTitles.length, 'cards');
  }

  // ── CARD DETECTOR V1 ─────────────────────────────────────
  // Detecteaza carduri repetitive cu titlu + pret + CTA
  // Functioneaza pentru Elementor, WooCommerce, orice grid de servicii
  
  // Pattern 1: Elementor heading sequence (titlu → pret → CTA)
  // Extrage toate h1-h6 cu clasa elementor-heading-title
  const cardHeadings = [];
  const ehRegex = /<h[1-6][^>]*elementor-heading-title[^>]*>([\s\S]{0,600}?)<\/h[1-6]>/gi;
  let ehMatch;
  while ((ehMatch = ehRegex.exec(html)) !== null) {
    const raw = ehMatch[1];
    const text = raw.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
    const priceM = raw.match(/(\d{1,5}(?:[.,]\d{0,2})?)\s*(?:Lei|RON|ron|lei|€)/i);
    cardHeadings.push({ text, price: priceM ? priceM[1] : null, raw });
  }
  
  if (cardHeadings.length >= 3) {
    let i = 0;
    while (i < cardHeadings.length) {
      const h = cardHeadings[i];
      if (h.price) {
        let nameIdx = i - 1;
        while (nameIdx >= 0 && !isValidName(cardHeadings[nameIdx].text)) nameIdx--;
        if (nameIdx >= 0) {
          const name = cardHeadings[nameIdx].text
            .replace(/^(Pachete?|Servicii?|Tratament[e]?)\s*/i,'')
            .trim();
          if (isValidName(name) && name.length > 3) {
            add(name, h.price + ' LEI', 'elementor_card', 'elementor card detector', 88);
          }
        }
      }
      i++;
    }
  }
  
  // Pattern 2: Lista cu structura Nume + Pret (li sau div repetitive)
  // Gaseste blocuri <li> sau <div> care contin atat un titlu cat si un pret
  const listItemRegex = /<li[^>]*>([\s\S]{0,500}?)<\/li>/gi;
  let liMatch;
  while ((liMatch = listItemRegex.exec(html)) !== null) {
    const content = liMatch[1];
    const priceM = content.match(/(\d{2,5})\s*(?:Lei|RON|ron|lei|€)/i);
    if (!priceM) continue;
    // Extract text content
    const text = content.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
    // First line before the price is usually the name
    const beforePrice = text.substring(0, text.search(/\d{2,5}\s*(?:Lei|RON)/i)).trim();
    // Take last meaningful phrase as name
    const parts = beforePrice.split(/[,;(]/).map(p=>p.trim()).filter(p=>p.length>3);
    if (parts.length > 0) {
      const name = parts[0].substring(0, 80).trim();
      if (isValidName(name)) {
        add(name, priceM[1] + ' LEI', 'list_card', 'list item card', 82);
      }
    }
  }

  // ── END CARD DETECTOR ──────────────────────────────────────

  // DataLayer ecommerce extraction (Google Analytics / WooCommerce)
  const dataLayerMatches = [...html.matchAll(/dataLayer\.push\s*\(\s*\{[\s\S]{0,2000}?'ecommerce'[\s\S]{0,2000}?\}\s*\)/g)];
  for (const m of dataLayerMatches) {
    try {
      // Extract items from dataLayer
      const itemsMatch = m[0].match(/'items'\s*:\s*\[([\s\S]+?)\]/);
      if (itemsMatch) {
        const itemsStr = itemsMatch[1];
        const nameMatches = [...itemsStr.matchAll(/'item_name'\s*:\s*'([^']+)'/g)];
        const priceMatches = [...itemsStr.matchAll(/'price'\s*:\s*(\d+(?:\.\d+)?)/g)];
        nameMatches.forEach((nm, i) => {
          const name = nm[1].trim();
          const price = priceMatches[i] ? priceMatches[i][1] + ' RON' : null;
          if (isValidName(name)) add(name, price, 'datalayer', 'google datalayer', 88);
        });
      }
      // Also try value field for single product pages
      const valueMatch = m[0].match(/'value'\s*:\s*(\d+)/);
      const nameMatch = m[0].match(/'item_name'\s*:\s*'([^']+)'/);
      if (valueMatch && nameMatch && isValidName(nameMatch[1])) {
        add(nameMatch[1].trim(), valueMatch[1] + ' RON', 'datalayer', 'datalayer value', 85);
      }
    } catch(e) {}
  }

  // Elementor/WordPress price widgets (86%)
  // Pattern: heading widget with name, then another with price
  const elementorHeadings = [...html.matchAll(/<h[1-6][^>]*elementor[^>]*>([\s\S]{0,500}?)<\/h[1-6]>/gi)];
  if (elementorHeadings.length > 0) {
    const headTexts = elementorHeadings.map(m => m[1].replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());
    for (let i = 0; i < headTexts.length - 1; i++) {
      const nameText = headTexts[i];
      const nextText = headTexts[i+1];
      // If current is a name and next has a price
      const pm = nextText.match(/(\d{1,5})\s*(?:Lei|RON|ron|€)/i);
      if (pm && isValidName(nameText) && nameText.length > 3 && nameText.length < 100) {
        add(nameText.replace(/\s+/g,' ').trim(), pm[1]+' LEI', 'elementor', 'elementor heading', 86);
      }
    }
  }

  // Consecutive lines (78%) — always run, not just when few services
  for (let i = 0; i < lines.length-1; i++) {
    // Pattern: name on line i, "de la X RON" or "X RON" on line i+1
    const pm = lines[i+1].match(/^(?:de la\s+)?(\d{1,5}(?:[.,–\-]\d{0,3})?(?:\s*[–\-]\s*\d{1,5})?)\s*(?:Lei|RON|ron|€)/i);
    if (pm && isValidName(lines[i]) && lines[i].length > 3 && lines[i].length < 100) {
      const price = pm[1].replace(/\s+/g,'') + ' RON';
      add(lines[i].replace(/[:\-–]+$/,'').trim(), price, 'consecutive', 'consecutive lines', 78);
    }
    // Pattern: "Serviciu | de la X RON" on same line (split by |)
    const parts = lines[i].split('|').map(p => p.trim());
    if (parts.length >= 2) {
      const namePart = parts[0];
      const pricePart = parts.find(p => /\d+\s*RON/i.test(p));
      if (pricePart && isValidName(namePart)) {
        const pm2 = pricePart.match(/(\d{1,5}(?:\s*[–\-]\s*\d{1,5})?)\s*RON/i);
        if (pm2) add(namePart.replace(/[:\-–]+$/,'').trim(), pm2[1].replace(/\s+/g,'')+' RON', 'pipe_split', 'name|price', 80);
      }
    }
  }

  // ── GENERIC CARD DETECTOR (LovelySkin / plain headings) ──────────
  // Works for ANY site: a heading (h2-h6) that is a plausible service
  // name followed within a window by a price "350 Lei" / "350 RON".
  // No dependency on Elementor/WoodMart/WooCommerce classes.
  const genericJunk = /(reducer|reducere|promotie|oferte|toate|detalii|mai multe|inapoi|programazi|contact|acasa|home|menu|despre noi|echipa noastra|beneficia|descopera|invit|curioz|alegem|informatii|tarife actuale|ore de program|luni|vineri|samb|dumin|telefon|adresa|email)/i;
  const gHead = [];
  const ghRegex = /<h([2-6])([^>]*)>([\s\S]{0,400}?)<\/h\1>/gi;
  let gh;
  while ((gh = ghRegex.exec(html)) !== null) {
    const raw = gh[3];
    const text = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    if (!text || text.length < 3 || text.length > 90) continue;
    if (!/[a-zA-ZăâîșțĂÂÎȘȚ]{3,}/.test(text)) continue;
    if (genericJunk.test(text)) continue;
    gHead.push({ text, end: gh.index + gh[0].length });
  }
  const usedPriceBucket = new Set();
  for (const h of gHead) {
    const windowText = html.slice(h.end, h.end + 3500);
    // Find the FIRST complete number in the window and check it is a price.
    // A "complete number" = all consecutive digits/./, grouped, so we never
    // capture a tail fragment like "000" out of "5.000".
    const numRe = /\d{1,6}(?:[.,]\d{1,6})*/g;
    const nms = [...windowText.matchAll(numRe)];
    let match = null;
    for (const cand of nms) {
      const numStr = cand[0];
      const after = windowText.slice(cand.index + numStr.length, cand.index + numStr.length + 6);
      if (/^\s*(?:lei|ron|RON|€|eur|LEI)/i.test(after)) {
        match = { price: numStr, abs: h.end + cand.index };
        break;
      }
    }
    if (!match) continue;
    if (/[.,]/.test(match.price.slice(0, 1))) continue;
    const bucket = Math.floor(match.abs / 80);
    if (usedPriceBucket.has(bucket)) continue;
    usedPriceBucket.add(bucket);
    let name = h.text.split('|')[0].replace(/\s+/g, ' ').trim();
    if (/[.?!…]$/.test(name)) continue;
    if (name.length < 3 || name.length > 90) continue;
    const words = name.split(/\s+/).filter(Boolean);
    if (words.length > 25) continue;
    add(name, match.price + ' LEI', 'generic_card', 'generic heading+price', 86);
  }

  return {
    type: 'services',
    items: services.slice(0,60),
    confidence: services.length>10?90:services.length>3?70:services.length>0?50:0,
    source: ['json_ld','html_table','html_list','text_lines','generic_card'],
    warnings: [], durationMs: 0,
  };
}

module.exports = { extractServices };
